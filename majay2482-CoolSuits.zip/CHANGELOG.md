## v1.0.0
- Adds A Couple Suits To The Game
